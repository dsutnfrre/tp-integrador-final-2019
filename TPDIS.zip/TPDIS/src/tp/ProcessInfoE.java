package tp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ProcessInfoE")
public class ProcessInfoE extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ProcessInfoE() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con = getConnection();
		HttpSession session = request.getSession(true);
		
		
		
		if(request.getParameter("guardar")!=null) {
			String name = request.getParameter("name");
			Integer dni = Integer.parseInt(request.getParameter("dni"));
			String phone = request.getParameter("phone");
			String email = request.getParameter("email");
			String dir = request.getParameter("dir");
			Short term = Short.parseShort(request.getParameter("term")) ;
			String text = request.getParameter("text");
			updateDBL(dni,term,text, con);
			updateDBC(name,dni,phone,email,dir, con);			
			getServletContext()
			.getRequestDispatcher("/Empleado.jsp")
			.forward(request, response);
			
		}
		if(request.getParameter("guardar2")!=null) {
			String name = request.getParameter("name");
			Integer dni = Integer.parseInt(request.getParameter("dni"));
			String phone = request.getParameter("phone");
			String email = request.getParameter("email");
			String dir = request.getParameter("dir");
			Short term = Short.parseShort(request.getParameter("term")) ;
			String text = request.getParameter("text");
			updateDBL(dni,term,text, con);
			updateDBC(name,dni,phone,email,dir, con);			
			getServletContext()
			.getRequestDispatcher("/CUaparte.jsp")
			.forward(request, response);
			
		}
		if(request.getParameter("holi")!=null) {
			getTDB(con, session);		
			
			RequestDispatcher despachador= request.getRequestDispatcher("/CUaparte.jsp");
			despachador.forward(request, response);
		}
	}
	
	public Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost/registrar_Llamada?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String user = "dbadmin";
            String pw = "dbadmin";
            con = DriverManager.getConnection(url,user,pw);
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return con;

    }
	
	protected void updateDBC(String nombre, Integer dni, String phone, String email, String dir, Connection con) {
		try {
			Statement s = con.createStatement();
			String query = "INSERT INTO cliente " + 
			        "(nombre_apellido, dni, telefono, email, direccion) " + 
			        "VALUES ('" + nombre +"','"+ dni +"','"+ phone +"','"+ email +"','"+ dir + "')";
			s.executeUpdate(query);
			
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		}
	
	protected void updateDBL(Integer dni, Short term, String text, Connection con) {
		try {
			Statement s = con.createStatement();
			String query = "INSERT INTO llamadas " + 
			        "(dni, duracion_llamada, motivo) " + 
			        "VALUES ('" + dni +"','"+ term +"','"+ text + "')";
			s.executeUpdate(query);
			
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		}
	
	protected static void getTDB(Connection con, HttpSession session) {
		 ArrayList<CXL> gente = new ArrayList<CXL>();
      try {
          Statement s = con.createStatement();
          String query = "SELECT DISTINCT * FROM llamadas INNER JOIN cliente ON llamadas.dni=cliente.dni";
          ResultSet res= s.executeQuery(query);
         
          while (res.next()) {
          	
              String id = res.getString("id_llamada");
              String dni = res.getString("dni");
              String term = res.getString("duracion_llamada");
              String text = res.getString("motivo");
              String date = res.getString("fecha_llamada");
              String name = res.getString("nombre_apellido");
              String phone = res.getString("telefono");
              String email = res.getString("email");
              String dir = res.getString("direccion");
              CXL cli = new CXL(name,dni,phone,email,dir,id,term,text,date);
              gente.add(cli);              
          }
          session.setAttribute("gente", gente);

      }
      catch(SQLException e){
          e.printStackTrace();
      }
  }
	
}
