package tp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import java.util.ArrayList;

@WebServlet("/ProcessInfo")
public class ProcessInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ProcessInfo() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/Empleado.jsp";
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("uname");
		String password = request.getParameter("pw");
		HttpSession session = request.getSession(true);
		EVP user = new EVP(username, password);
		if(request.getParameter("inicio")!= null) {
			if(compararEVP(username,password,session)) {
			request.setAttribute("user", user);
			getServletContext()
			.getRequestDispatcher(url)
			.forward(request, response);
			updateDB(username);
			}else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('User or password incorrect');");
				out.println("</script>");
				RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
				rd.include(request, response);
			}
		}
		
	}
	
	protected boolean compararEVP(String username, String password, HttpSession session) {
		Connection con = getConnection();
		boolean bandera= false;
		ArrayList<EVP> listaEVP = new ArrayList<EVP>();
		listaEVP = getTDB(con, session);
		try {
			for(int i=0; i<listaEVP.size();i++){
				if(username.equals(listaEVP.get(i).getUsername()) && password.equals(listaEVP.get(i).getPassword())) {
					bandera = true;
					
					}				
				}
			}
		finally {}
		return bandera;
		}
	
	protected void updateDB(String username) {
		Connection con = getConnection();
		try {
			Statement s = con.createStatement();
			String query = "INSERT INTO login " + 
			        "(usuario) " + 
			        "VALUES ('" + username + "')";
			s.executeUpdate(query);
			
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		}
	
	public Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost/registrar_Llamada?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String user = "dbadmin";
            String pw = "dbadmin";
            con = DriverManager.getConnection(url,user,pw);
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return con;

    }
	
	protected static ArrayList<EVP> getTDB(Connection con, HttpSession session) {
		 ArrayList<EVP> gente = new ArrayList<EVP>();
       try {
           Statement s = con.createStatement();
           String query = "SELECT * FROM inicio_sesion";
           ResultSet res= s.executeQuery(query);
          
           while (res.next()) {
           	
               String username = res.getString("usuario");
               String password = res.getString("contraseña");
               EVP lista = new EVP(username, password);
               gente.add(lista);
           }
           session.setAttribute("gente", gente);

       }
       catch(SQLException e){
           e.printStackTrace();
       }
       return gente;
   }
	
}
