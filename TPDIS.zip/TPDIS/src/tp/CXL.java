package tp;

import java.io.Serializable;

public class CXL implements Serializable{
	private static final long serialVersionUID = 1L;
	private String name;
	private String dni;
	private String phone;
	private String email;
	private String dir;
	private String id;
	private String term;
	private String text;
	private String date;
	
	public CXL() {
		this.name="";
		this.dni="";
		this.phone="";
		this.email="";
		this.dir="";
		this.id="";
		this.term="";
		this.text="";
		this.date="";
	}
	
	public CXL(String name, String dni, String phone, String email, String dir,String id, String term, String text, String date) {
		this.name=name;
		this.dni=dni;
		this.phone=phone;
		this.email=email;
		this.dir=dir;
		this.id=id;
		this.term=term;
		this.text=text;
		this.date=date;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDir() {
		return dir;
	}
	public void setDir(String dir) {
		this.dir = dir;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
