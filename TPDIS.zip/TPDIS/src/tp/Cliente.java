package tp;

import java.io.Serializable;

public class Cliente implements Serializable{
	private static final long serialVersionUID = 1L;
	private String name;
	private String dni;
	private String phone;
	private String email;
	private String dir;
	
	public Cliente() {
		this.name="";
		this.dni="";
		this.phone="";
		this.email="";
		this.dir="";		
	}
	
	public Cliente(String name, String dni, String phone, String email, String dir) {
		this.name=name;
		this.dni=dni;
		this.phone=phone;
		this.email=email;
		this.dir=dir;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDir() {
		return dir;
	}
	public void setDir(String dir) {
		this.dir = dir;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
