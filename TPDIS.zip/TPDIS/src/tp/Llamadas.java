package tp;
import java.io.Serializable;
public class Llamadas implements Serializable{
	private static final long serialVersionUID = 1L;
	private String id;
	private String dni;
	private String term;
	private String text;
	private String date;
	
	public Llamadas() {
		this.id="";
		this.dni="";
		this.term="";
		this.text="";
		this.date="";
	}
	
	public Llamadas(String id,String dni, String term, String text, String date) {
		this.id=id;
		this.dni=dni;
		this.term=term;
		this.text=text;
		this.date=date;
	}
	
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
