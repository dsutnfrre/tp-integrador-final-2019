var texto1 = document.getElementById ("usu")
var texto2 = document.getElementById ("pass")