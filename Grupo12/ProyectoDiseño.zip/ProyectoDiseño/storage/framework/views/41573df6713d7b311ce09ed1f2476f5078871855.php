<!DOCTYPE html>
<html lang="zxx">
   <head>
      <title>MAXELEC.SA - Autenticación</title>
      <!--meta tags -->

      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="Renovate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
         SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
      <?php echo Html::style('css/bootstrap2.min.css'); ?>

      <?php echo Html::style('css/style.css'); ?>

      <!-- <?php echo Html::style('css/metisMenu.min.css'); ?> -->
      <!-- <?php echo Html::style('css/sb-admin-2.css'); ?> -->
      <!-- <?php echo Html::style('css/font-awesome.min.css'); ?> -->
      
      <!-- <?php echo Html::style('css/bootstrap.min.css'); ?> -->
      <!-- <?php echo Html::style('css/fontawesome-all.min.css'); ?> -->
      <!-- <?php echo Html::style('css/popup-box.css'); ?>   -->
      
      <!-- <?php echo Html::style('//fonts.googleapis.com/css?family=Raleway:400,500,600'); ?> -->
      <!-- <?php echo Html::style('//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700'); ?> -->
     
   </head>
   <body>
      
            <div class="container-fluid">
               <div class="row headder-contact" style="background: #3b3bb1;" >
                     <div class="hedder-up col-lg-12 col-md-8 col-sm-6" style="text-align: left; padding: initial">
                        <h1><a class="navbar-brand" href="<?php echo URL::to('/'); ?>">MAXELEC.SA</a></h1>
                      </div> 
                      <div class="hedder-up col-lg-12 col-md-8 col-sm-6" style="text-align: left;">
                        <h6 style="color: #c7cace;">Termotanques y Calefones</h6>
                      </div>                                                                 
               </div>
               <div class="clearfix"> </div>
            </div>
      <div class="container"  style="padding:20px;">      
         <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <br>
         <?php echo Form::open(['route'=>'log.store','method'=>'POST']); ?>

            <div class="row">
               <div class="col-md-12 col-md-offset-4">  
                  <br>            
                  <form name="login" class="needs-validation" novalidate="">
                     <div class="row text-center">
                        <div class="col-md-4 mb-4">
                           <h3 class="" style="color:#337ab7 ">Autenticación</h3>
                        </div>
                     </div>                
                     <br>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12 col-md-offset-4">  
                        <div class="col-md-4 mb-4 input-group">
                           <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                           <?php echo Form::text('nombreUsuario',null,['class'=>'form-control', 'placeholder'=>'Ingrese su usuario']); ?>

                        </div>
               </div>
            </div>
            <br>
            <div class="row">
               <div class="col-md-12 col-md-offset-4"> 
                        <div class="col-md-4 mb-4 input-group">
                           <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                           <?php echo Form::password('password',['class'=>'form-control', 'placeholder'=>'Ingrese su contraseña']); ?>

                           
                        </div>
               </div>
            </div>
               <br>
            <div class="col-md-10 col-md-offset-4"> 
                  <div class=" form-inline col-md-4 mb-2 text-center">
                        <button type="button" class="btn btn-success" onclick="window.location.href='<?php echo URL::to('/'); ?>'">Volver a la Web</button>                
                        <?php echo Form::submit('Ingresar',['class'=>'btn btn-info','route'=>'/']); ?>                        
                  </div>
            </div>
         <?php echo Form::close(); ?>       
      </div>
         
   </body>
   <?php echo Html::script('js/jquery-2.2.3.min.js'); ?>

      <?php echo Html::script('js/responsiveslides.min.js'); ?>

      <?php echo Html::script('js/jquery.waypoints.min.js'); ?>

      <?php echo Html::script('js/jquery.countup.js'); ?>   
      <?php echo Html::script('js/jquery.magnific-popup.js'); ?>     
     
      <?php echo Html::script('js/move-top.js'); ?>

      <?php echo Html::script('js/easing.js'); ?>

      <?php echo Html::script('js/bootstrap.min.js'); ?>

      
      <!-- <?php echo Html::script('js/jquery.min.js'); ?> -->
      <?php echo Html::script('js/bootstrap2.min.js'); ?>

      <?php echo Html::script('js/metisMenu.min.js'); ?>

      <?php echo Html::script('js/sb-admin-2.js'); ?>

</html>