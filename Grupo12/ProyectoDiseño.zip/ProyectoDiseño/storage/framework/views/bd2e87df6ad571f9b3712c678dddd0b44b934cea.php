<?php $__env->startSection('content2'); ?>
                  <div class="collapse navbar-collapse  nav-fill " id="navbarSupportedContent">
                     <ul class="navbar-nav nav-pills nav-fill">
                        <li class="nav-item">
                           <a class="nav-link" href="/">Inicio</a>
                        </li>
                        <li class="nav-item">
                           <a href="/productos" class="nav-link">Productos</a>
                        </li>
                        <li class="nav-item ">
                           <a href="/nosotros" class="nav-link ">Nosotros</a>
                        </li>
                        <li class="nav-item active">
                           <a href="/servicios" class="nav-link ">Servicios</a>
                        </li>
                        <li class="nav-item dropdown">
                           <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           Mas Información
                           </a>
                           <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item" href="/preguntas">Preguntas Frecuentes</a>
                              <a class="dropdown-item" href="/manuales">Manuales</a>
                              <a class="dropdown-item" href="typography.html">Videos Tutorial</a>
                           </div>
                        </li>
                        
                        <li class="nav-item ">
                           <a href="/contacto" class="nav-link">Contacto</a>
                        </li>
                     </ul>
                  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content1'); ?>
   <!-- banner -->
      <div class="inner_page-banner one-img"></div>
   <!--//banner -->
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <!--Services -->
        <section class="service-one py-lg-4 py-md-3 py-sm-3 py-3" id="about">
            <div class="container py-lg-5 py-md-5 py-sm-4 py-4">
                <div class="title-sub text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
                    <h3 class="title mb-md-4 mb-sm-3 mb-3">Our Services</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do<br>tempor incididunt ut labore et</p>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6 service-inner-list">
                        <div class="ser-inner-agile">
                            <div class="ser-w3layouts-inner">
                                <img src="images/s1.jpg" alt=" " class="img-fluid">
                            </div>
                            <div class="ser-txt-inner">
                                <h4 class="py-3">Floor Cleaning</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna, euismod ut ornare non</p>
                            </div>
                        </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 service-inner-list">
                        <div class="ser-inner-agile">
                            <div class="ser-w3layouts-inner">
                                <img src="images/s2.jpg" alt=" " class="img-fluid">
                            </div>
                            <div class="ser-txt-inner">
                                <h4 class="py-3">Roof Cleaning</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna, euismod ut ornare non</p>
                            </div>
                        </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 service-inner-list">
                        <div class="ser-inner-agile">
                            <div class="ser-w3layouts-inner">
                                <img src="images/s3.jpg" alt=" " class="img-fluid">
                            </div>
                            <div class="ser-txt-inner">
                                <h4 class="py-3">Carpet Cleaning</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna, euismod ut ornare non</p>
                            </div>
                        </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 mt-lg-4 mt-md-3 mt-3 service-inner-list">
                        <div class="ser-inner-agile">
                            <div class="ser-w3layouts-inner">
                                <img src="images/s4.jpg" alt=" " class="img-fluid">
                            </div>
                            <div class="ser-txt-inner">
                                <h4 class="py-3">Window Cleaning</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna, euismod ut ornare non</p>
                            </div>
                        </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 mt-lg-4 mt-md-3 mt-3 service-inner-list">
                        <div class="ser-inner-agile">
                            <div class="ser-w3layouts-inner">
                                <img src="images/s1.jpg" alt=" " class="img-fluid">
                            </div>
                            <div class="ser-txt-inner">
                                <h4 class="py-3">House Cleaning</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna, euismod ut ornare non</p>
                            </div>
                        </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 mt-lg-4 mt-md-3 mt-3 service-inner-list">
                        <div class="ser-inner-agile">
                            <div class="ser-w3layouts-inner">
                                <img src="images/s2.jpg" alt=" " class="img-fluid">
                            </div>
                            <div class="ser-txt-inner">
                                <h4 class="py-3">After Renovation</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna, euismod ut ornare non</p>
                            </div>
                        </div>
                </div>
            </div>
         
      </section>
      <!--//service -->
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>