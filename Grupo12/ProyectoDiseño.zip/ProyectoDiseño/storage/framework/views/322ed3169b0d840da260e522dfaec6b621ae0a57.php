<?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-8 order-md-1">
  <br>
  <table class="table">
    <thead>
      <th>Nombre Usuario</th>
      <th>Correo Electrónico</th>
      <th>Fecha de Creación</th>
      <th>Telefono</th>
      <th></th>
    </thead>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
      <td><?php echo e($user->nombreUsuario); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td><?php echo e($user->fecha_creacion); ?></td>
      <td><?php echo e($user->telefono); ?></td>
      <td class="text-center">
        <?php echo link_to_route('usuarios.edit', $title = 'Editar', $parameters = $user, $attributes = ['class'=>'btn
        btn-primary']); ?>

      </td>
      <td>
        <?php echo Form::open(['route'=>['usuarios.destroy', $user], 'method' => 'DELETE']); ?>

        <?php echo Form::submit('Eliminar',['class'=>'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

      </td>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>