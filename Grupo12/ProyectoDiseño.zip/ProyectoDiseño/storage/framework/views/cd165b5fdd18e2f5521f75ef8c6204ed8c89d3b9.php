<?php $__env->startSection('content'); ?>
<img src="/images/Captura2.jpg" class="img-fluid" alt="Responsive image" style="padding-top: 180px;
padding-left: 320px;">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>