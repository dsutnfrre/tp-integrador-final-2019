<?php $__env->startSection('content'); ?>
<div class="col-md-10 col-md-offset-2">
          <h3 class="mb-3" style="color:#337ab7">Editar reclamo</h3>
          <br>
          <form class="needs-validation" novalidate="">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="fecha">Fecha de Reclamo</label>
                    <input type="datetime" class="form-control" id="fecha" name="fecha"  value="<?php echo date("d-m-Y");?>">
                </div>
                <div class="col-md-3 mb-3">
                    <label for="numreclamo">N° Reclamo</label>
                    <input type="text" class="form-control" id="numreclamo" value="454584" disabled>
                </div>
                <div class="col-md-3 mb-3">
                    <label for="estado">Estado</label>
                    <select class="form-control" id="estado" required="">
                        <option value="">Abierto</option>
                        <option>Cerrado</option>
                        <option>En gestión</option>
                        <option>Abierto</option>
                    </select>
                </div> 
            </div>           
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="IdProd">Id Producto</label>
                    <input type="text" class="form-control" id="idProd" placeholder="ID Producto" value="" required="">
                </div>
                <div class="col-md-3 mb-3">
                    <label for="tipop">Tipo de Producto</label>
                        <select class="form-control" id="tipop" required="">
                            <option value="">Termotanque</option>
                            <option>Termotanque</option>
                            <option>Calefon</option>
                        </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="DNI">DNI Cliente</label>
                    <input type="text" class="form-control" id="dni" placeholder="DNI" value="30999888" required="">
                 </div>
                <div class="col-md-6 mb-4">
                    <label for="nomap">Nombre y Apellido</label>
                    <input type="text" class="form-control" id="nomap" placeholder="Nombre y Apellido del cliente" value="Gonzales Carlos">
                </div> 
            </div>
            <div class="row">
                <div class="col-md-9 mb-4">
                    <label for="domicilio">Domicilio</label>
                    <input type="text" class="form-control" id="domicilio" placeholder="Domicilio" value="Santa Fe 325" required="">
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="ciudad">Ciudad</label>
                    <input type="text" class="form-control" id="ciudad" placeholder="Ciudad" value="Resistencia" required="">
              </div>
                <div class="col-md-3 mb-3">
                        <label for="provincia">Provincia</label>
                        <input type="text" class="form-control" id="provincia" placeholder="Provincia" value="Chaco" required="">
                </div>
                <div class="col-md-3 mb-3">
                    <label for="pais">País</label>
                    <select class="form-control" id="pais" required="">
                    <option value="">Argentina</option>
                    <option>Argentina</option>
                    <option>Paraguay</option>
                    </select>
                </div> 
            </div>
            <div class="row">             
                <div class="col-md-6 mb-4">
                    <label for="detalle">Detalle de Reclamo</label>
                    <textarea class="form-control" id="detalle" rows="3">Termotanque se apaga solo al rato de encender y no prende más</textarea>
                </div>   
                <div class="col-md-3 mb-4">
                        <label for="estado">Horario de visita</label>
                        <select class="form-control" id="estado" required="">
                        <option value="">08:00 a 12:00</option>
                        <option>08:00 a 12:00</option>
                        <option>16:00 a 20:00</option>
                        </select>
                </div> 
            </div> 
            <!-- <div class="row">  -->
                
                <!-- <div class="col-md-7 mb-5">
                    <label for="mapa">Servicio Tecnico</label>
                        <div class="card-body card-body-cascade text-center">
                            <div id="map-container-google-8" class="z-depth-1-half map-container-5" style="height: 300px">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3540.4642719154763!2d-58.98073318494338!3d-27.454801982897113!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2sar!4v1560893799490!5m2!1ses-419!2sar"
                                    frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>
                        </div>                    
                </div>               -->
            <!-- </div> -->
            <div class="row">
                 <hr style="margin-top:10px; margin-bottom:10px;">
                <div class="col-md-6 mb-4 text-left">
                    <textarea class="form-control" id="cierre" rows="2" placeholder="Detalle de cierre"></textarea>
                </div>
                <div class="col-md-3 mb-4 text-right">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                        Guardar
                    </button>
                </div>
            </div>
            
          </form>
          <br>
</div>
<!-- The Modal -->
<div class="modal" id="myModal">
        <div class="modal-dialog">
          <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
              <h4 class="modal-title">Reclamo Guardado</h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
             El reclamo se guardo correctamente
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="window.location.href='/listareclamos'">Cerrar</button>
            </div>

          </div>
        </div>
      </div>

   
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>